# Describe la configuración del paquete distribuible
# una vez relleno hay que ejecutar en consola python setup.py sdist

from setuptools import setup

setup(
    name = "paquete_distribuible",
    version = "0.01",
    descripción = "ejemplo de paquete distribuible con funciones de redonde y potencia",
    author = "angegon",
    author_email = "angegon@gmail.com",
    url = "https://github.com/angegon",
    packages = ["paquete", "paquete.redondeo_potencia"]
)