def Sumar(op1, op2):
    print("El resultado de la suma es: ", op1 + op2)

def Restar(op1, op2):
    print("El resultado de la resta es: ", op1 - op2)

def Multiplicar(op1, op2):
    print("El resultado de la multiplicación es: ", op1 * op2)

def Dividir(dividendo, divisor):
    print("El resultado de la división es: ", dividendo/divisor)

def Potencia(base, exponente):
    print("El resultado de la potencia es: ", base**exponente)

def Redondear(numero):
    print("El resultado del redondeo es: ", round(numero))